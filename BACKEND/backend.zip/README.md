# VendorBridge ERP

Procurement and Vendor Management ERP built from the provided VendorBridge PDF and Excalidraw screens.

## Features

- Login and signup screens with role selection.
- Proper local authentication: login checks existing account, password, and matching role.
- Signup with any valid email address.
- Role-based navigation and views for Admin, Procurement Officer, Vendor, and Manager / Approver.
- User profile page with account details and allowed modules.
- Clean logout with session clearing.
- Dashboard with active RFQs, approvals, purchase orders, invoices, spend trends, and quick actions.
- Vendor management with categories, GST, contact details, statuses, search, and filters.
- RFQ creation with line items, deadline, vendor assignment, and attachments panel.
- Vendor quotation submission with pricing, delivery days, GST, terms, and live totals.
- Quotation comparison with lowest-price highlight and vendor rating indicators.
- Approval workflow with timeline, remarks, approve/reject actions, and state changes.
- Purchase order and invoice screen with generated PO number, tax totals, print, PDF-download placeholder, email placeholder, and payment status update.
- Immutable activity and audit log UI.
- Reports and analytics screen with spend, vendor, PO fulfillment, overdue invoices, and monthly trends.
- Database schemas for PostgreSQL and MySQL.

## Run

```bash
npm install
npm start
```

Open `http://localhost:3000`.

The frontend is also static and can be opened directly from `frontend/index.html`, but the Node server is useful for API routes and future database integration.

## Database

Use either schema:

- PostgreSQL: `database/postgres.sql`
- MySQL: `database/mysql.sql`

Set environment variables before starting the server:

```bash
DB_TYPE=postgres
DATABASE_URL=postgres://user:password@localhost:5432/vendorbridge
```

or

```bash
DB_TYPE=mysql
DATABASE_URL=mysql://user:password@localhost:3306/vendorbridge
```

No third-party APIs are used. The only npm packages are local database drivers for PostgreSQL/MySQL.

## Demo Login Accounts

All demo users use password `password123`.

- Procurement Officer: `officer@vendorbridge.local`
- Admin: `admin@vendorbridge.local`
- Vendor: `vendor@vendorbridge.local`
- Manager / Approver: `approver@vendorbridge.local`

New users can signup with any valid email address. After signup, login requires the same email, password, and role selected during registration.
