const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const root = path.join(__dirname, "..");
const frontend = path.join(root, "frontend");
const port = Number(process.env.PORT || 3000);

// In-memory store matching the frontend seed data
const memory = {
  vendors: [
    { id:1, name:"Infra Supplies Pvt Ltd", category:"Furniture",   gst_no:"29ABCDE1234F125", contact_name:"Rahul Sharma",  email:"sales@infrasupplies.com", phone:"+91 98765 43210", rating:4.8, status:"Active" },
    { id:2, name:"Office Steel Co.",       category:"Furniture",   gst_no:"19MNOPQ9012MN24", contact_name:"Sanjay Gupta",  email:"gov@officesteel.com",     phone:"+91 98300 12345", rating:4.2, status:"Active" },
    { id:3, name:"PaperKraft Stationery",  category:"Stationery",  gst_no:"07RSTUV3456NA29", contact_name:"Neha Patel",    email:"support@paperkraft.com",  phone:"+91 91234 56789", rating:4.6, status:"Active" },
    { id:4, name:"TechCore Ltd",           category:"IT Hardware", gst_no:"27GHIJK5678LZ23", contact_name:"Vikram Aditya", email:"contracts@techcore.com",  phone:"+91 99988 77665", rating:4.5, status:"Active" },
  ],
  rfqs: [
    { id:1, title:"Office Furniture Procurement Q2", category:"Furniture", deadline:"2026-06-30", status:"Published", created_at: new Date().toISOString() }
  ],
  activity_logs: [
    { id:1, module:"AUTH",     user:"Rishit Patel",   role:"Procurement Officer", event:"User logged in",    detail:"Login successful for rishitpatel2509@gmail.com", created_at:"2026-06-06T11:05:29" },
    { id:2, module:"RFQ",      user:"Rohan Deshmukh", role:"Procurement Officer", event:"Created RFQ",       detail:"Office Furniture Procurement Q2 created",         created_at:"2026-06-06T10:09:22" },
    { id:3, module:"QUOTATION",user:"Rahul Sharma",   role:"Vendor",              event:"Quotation submitted",detail:"Submitted for Office Furniture Procurement Q2",   created_at:"2026-06-06T10:09:22" },
    { id:4, module:"APPROVAL", user:"Siddharth Mehta",role:"Manager",             event:"Quotation approved", detail:"Vendor 1 selected - lowest bid",                  created_at:"2026-06-06T10:09:22" },
  ]
};

async function getDb() {
  const type = process.env.DB_TYPE;
  const connectionString = process.env.DATABASE_URL;
  if (!type || !connectionString) return null;
  if (type === "postgres") {
    const { Pool } = require("pg");
    const pool = new Pool({ connectionString });
    return { async query(sql, params) { const r = await pool.query(sql, params); return r.rows; } };
  }
  if (type === "mysql") {
    const mysql = require("mysql2/promise");
    const pool = mysql.createPool(connectionString);
    return { async query(sql, params) { const [rows] = await pool.execute(sql, params); return rows; } };
  }
  throw new Error("DB_TYPE must be postgres or mysql");
}

let dbPromise = getDb().catch(err => { console.warn("Database disabled:", err.message); return null; });

function send(res, status, body, type = "application/json") {
  const isJson = type === "application/json";
  res.writeHead(status, {
    "Content-Type": type,
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  });
  res.end(isJson ? JSON.stringify(body) : body);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", c => { data += c; });
    req.on("end", () => { try { resolve(data ? JSON.parse(data) : {}); } catch(e) { reject(e); } });
  });
}

async function api(req, res, url) {
  const db = await dbPromise;

  // OPTIONS preflight
  if (req.method === "OPTIONS") return send(res, 204, "", "text/plain");

  // Health
  if (url.pathname === "/api/health") return send(res, 200, { ok:true, db: db ? process.env.DB_TYPE : "memory" });

  // ── VENDORS ──
  if (url.pathname === "/api/vendors" && req.method === "GET") {
    if (db) { const rows = await db.query("select * from vendors order by id"); return send(res, 200, rows); }
    return send(res, 200, memory.vendors);
  }
  if (url.pathname === "/api/vendors" && req.method === "POST") {
    const body = await readJson(req);
    if (!body.name || !body.gst_no) return send(res, 400, { error:"name and gst_no required" });
    if (db) {
      const sql = process.env.DB_TYPE === "postgres"
        ? "insert into vendors (name,category,gst_no,contact_name,email,phone,status) values ($1,$2,$3,$4,$5,$6,$7) returning *"
        : "insert into vendors (name,category,gst_no,contact_name,email,phone,status) values (?,?,?,?,?,?,?)";
      const rows = await db.query(sql, [body.name, body.category, body.gst_no, body.contact_name, body.email, body.phone, body.status||"Active"]);
      return send(res, 201, rows[0] || body);
    }
    const v = { id: memory.vendors.length + 1, status:"Active", rating:0, ...body };
    memory.vendors.push(v);
    return send(res, 201, v);
  }
  if (url.pathname.startsWith("/api/vendors/") && req.method === "DELETE") {
    const id = Number(url.pathname.split("/").pop());
    if (db) { await db.query("delete from vendors where id=$1", [id]); return send(res, 200, { ok:true }); }
    memory.vendors = memory.vendors.filter(v => v.id !== id);
    return send(res, 200, { ok:true });
  }

  // ── RFQs ──
  if (url.pathname === "/api/rfqs" && req.method === "GET") {
    if (db) { const rows = await db.query("select * from rfqs order by id desc"); return send(res, 200, rows); }
    return send(res, 200, memory.rfqs);
  }
  if (url.pathname === "/api/rfqs" && req.method === "POST") {
    const body = await readJson(req);
    if (!body.title) return send(res, 400, { error:"title required" });
    if (db) {
      const sql = process.env.DB_TYPE === "postgres"
        ? "insert into rfqs (title,category,deadline,status) values ($1,$2,$3,$4) returning *"
        : "insert into rfqs (title,category,deadline,status) values (?,?,?,?)";
      const rows = await db.query(sql, [body.title, body.category, body.deadline, body.status||"Draft"]);
      return send(res, 201, rows[0] || body);
    }
    const rfq = { id: memory.rfqs.length + 1, status:"Draft", created_at: new Date().toISOString(), ...body };
    memory.rfqs.push(rfq);
    return send(res, 201, rfq);
  }

  // ── ACTIVITY LOGS ──
  if (url.pathname === "/api/activity-logs" && req.method === "GET") {
    if (db) { const rows = await db.query("select * from activity_logs order by created_at desc"); return send(res, 200, rows); }
    return send(res, 200, memory.activity_logs);
  }
  if (url.pathname === "/api/activity-logs" && req.method === "POST") {
    const body = await readJson(req);
    if (db) {
      const sql = process.env.DB_TYPE === "postgres"
        ? "insert into activity_logs (module,user,role,event,detail) values ($1,$2,$3,$4,$5) returning *"
        : "insert into activity_logs (module,user,role,event,detail) values (?,?,?,?,?)";
      const rows = await db.query(sql, [body.module, body.user, body.role, body.event, body.detail]);
      return send(res, 201, rows[0] || body);
    }
    const log = { id: memory.activity_logs.length + 1, created_at: new Date().toISOString(), ...body };
    memory.activity_logs.unshift(log);
    return send(res, 201, log);
  }

  return send(res, 404, { error:"API route not found" });
}

function staticFile(req, res, url) {
  const requested = url.pathname === "/" ? "/index.html" : url.pathname;
  const filePath = path.normalize(path.join(frontend, requested));
  if (!filePath.startsWith(frontend)) return send(res, 403, "Forbidden", "text/plain");
  fs.readFile(filePath, (err, data) => {
    if (err) return send(res, 404, "Not found", "text/plain");
    const ext = path.extname(filePath);
    const types = { ".css":"text/css", ".js":"text/javascript", ".html":"text/html", ".json":"application/json", ".ico":"image/x-icon" };
    send(res, 200, data, types[ext] || "application/octet-stream");
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname.startsWith("/api/")) {
    api(req, res, url).catch(err => send(res, 500, { error: err.message }));
    return;
  }
  staticFile(req, res, url);
});

server.listen(port, () => console.log(`VendorBridge ERP → http://localhost:${port}`));
